library(testthat)
library(art)

test_check("art")
